#!/bin/sh
# Disable opkg signature check
sed -i 's/option check_signature/# option check_signature/g' /etc/opkg.conf

# Set Timezone to Asia/Jakarta
uci set system.@system[0].timezone='WIB-7'
uci set system.@system[0].zonename='Asia/Jakarta'
uci commit

# Folder untuk tinyfm
cd
ln /etc/openclash -s /www/tinyfm/openclash
ln / -s /www/tinyfm/rootfs

#hapus usb modeswitch untuk dw5821e
sed -i -e '/413c:81d7/,+5d' /etc/usb-mode.json

#fix auto reconnect modem manager
cd /usr/lib/ModemManager/connection.d
rm 10-report-down
chmod 755 10-report-down-and-reconnect

#install
cd /root
opkg install *.ipk

exit 0


