#!/bin/sh
# Copyright 2022 Rafał Wabik (IceG) - From eko.one.pl forum
# MIT License

rm -rf /tmp/luci-indexcache
rm -rf /tmp/luci-modulecache/
exit 0
